# SA Calculator v92 — Global Public Currency API

## Provider configuration

The calculator uses a public, keyless provider chain directly from the app:

1. **Frankfurter v2 (primary):** `https://api.frankfurter.dev/v2/rates?base=USD&expand=providers`
2. **Open ER-API (fallback):** `https://open.er-api.com/v6/latest/USD`
3. **Fawaz Exchange API (fallback):** jsDelivr CDN, then Cloudflare Pages mirror.

No SA-owned API server, Cloudflare Worker, custom domain, API key, or provider secret is required for these providers. The app validates the response shape, ISO currency codes, per-currency observation dates, stale/future dates, and positive finite rates. It merges only valid observations and does not allow an older observation to replace a newer one.

## Rate freshness

These are **reference exchange rates**, not executable bank, card, remittance, or trading quotes. Frankfurter aggregates central-bank and other official reference sources; source publication schedules vary and many publish once or a few times per day. Open ER-API and Fawaz are daily-oriented sources. Refreshing the app does not force the upstream provider to publish a new quote. The UI must continue to show provider observation dates and the last local refresh time separately.

## Offline behavior

Last-known validated rates remain available from the app's local cache. If no valid network rate exists, the app's built-in estimates remain explicitly labelled as estimates. Never label cached or built-in values as live.

## Android usage

Run the app through Acode's local web preview or any HTTPS static host. Direct `file://` launching may be restricted by Android WebView network/CORS policies. For a public release, host the static app on HTTPS; no API backend deployment is needed.

## Provider references

- Frankfurter documentation: https://frankfurter.dev/
- Frankfurter v2 API: https://frankfurter.dev/v2/
- Open ER-API: https://open.er-api.com/
- Fawaz Exchange API: https://github.com/fawazahmed0/exchange-api
