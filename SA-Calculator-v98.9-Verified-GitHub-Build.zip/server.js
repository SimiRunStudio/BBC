// Static development server for SA Calculator. Currency rates come from public global APIs.
'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const PORT = Number(process.env.PORT || 8080);
const ROOT = path.resolve(__dirname);
const ROOT_REALPATH = fs.realpathSync(ROOT);
const SECURITY_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'no-referrer',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
  'Cross-Origin-Resource-Policy': 'same-origin',
  'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self' data:; connect-src 'self' https://cdn.jsdelivr.net https://latest.currency-api.pages.dev https://open.er-api.com https://api.frankfurter.dev; base-uri 'self'; form-action 'self'; frame-ancestors 'none'"
};

function send(res, status, body, type = 'application/json', extraHeaders = {}, headOnly = false) {
  if (res.headersSent) return res.destroy();
  const payload = Buffer.isBuffer(body) ? body : Buffer.from(String(body));
  res.writeHead(status, {
    'Content-Type': type,
    'Content-Length': payload.length,
    ...SECURITY_HEADERS,
    'Cache-Control': 'no-store',
    ...extraHeaders
  });
  res.end(headOnly ? undefined : payload);
}

function serve(res, pathname, headOnly = false) {
  let decoded;
  try {
    decoded = decodeURIComponent(pathname);
  } catch (_) {
    return send(res, 400, 'Bad request', 'text/plain; charset=utf-8');
  }

  // Reject NUL bytes before filesystem calls: Node throws synchronously for
  // paths containing them, which must never take down the static server.
  if (decoded.includes('\0')) {
    return send(res, 400, 'Bad request', 'text/plain; charset=utf-8', {}, headOnly);
  }

  const relative = decoded === '/' ? 'index.html' : decoded.replace(/^\/+/, '');
  let file;
  try { file = path.resolve(ROOT, relative); }
  catch (_) { return send(res, 400, 'Bad request', 'text/plain; charset=utf-8', {}, headOnly); }
  const rel = path.relative(ROOT, file);

  // path.relative prevents sibling-prefix traversal (e.g. /app-evil).
  if (rel === '..' || rel.startsWith(`..${path.sep}`) || path.isAbsolute(rel)) {
    return send(res, 403, 'Forbidden', 'text/plain; charset=utf-8', {}, headOnly);
  }
  // Never expose environment/configuration or hidden files over HTTP.
  if (rel.split(path.sep).some((part) => part.startsWith('.'))) {
    return send(res, 404, 'Not found', 'text/plain; charset=utf-8', {}, headOnly);
  }

  fs.stat(file, (statError, info) => {
    if (statError || !info.isFile()) {
      return send(res, 404, 'Not found', 'text/plain; charset=utf-8', {}, headOnly);
    }
    // Lexical path checks do not stop a symlink inside the app tree from
    // pointing outside it. Resolve the target before reading any bytes.
    fs.realpath(file, (realpathError, realFile) => {
      if (realpathError) {
        return send(res, 404, 'Not found', 'text/plain; charset=utf-8', {}, headOnly);
      }
      const realRelative = path.relative(ROOT_REALPATH, realFile);
      if (realRelative === '..' || realRelative.startsWith(`..${path.sep}`) || path.isAbsolute(realRelative)) {
        return send(res, 403, 'Forbidden', 'text/plain; charset=utf-8', {}, headOnly);
      }
      fs.readFile(realFile, (readError, data) => {
        if (readError) return send(res, 404, 'Not found', 'text/plain; charset=utf-8', {}, headOnly);
        const ext = path.extname(realFile).toLowerCase();
        const types = {
          '.html': 'text/html; charset=utf-8',
          '.js': 'text/javascript; charset=utf-8',
          '.css': 'text/css; charset=utf-8',
          '.json': 'application/json; charset=utf-8',
          '.svg': 'image/svg+xml',
          '.webmanifest': 'application/manifest+json; charset=utf-8',
          '.png': 'image/png',
          '.jpg': 'image/jpeg',
          '.jpeg': 'image/jpeg',
          '.webp': 'image/webp'
        };
        send(res, 200, data, types[ext] || 'application/octet-stream', {}, headOnly);
      });
    });
  });
}

function createServer() {
  return http.createServer((req, res) => {
    let pathname = '/';
    try { pathname = url.parse(req.url).pathname || '/'; }
    catch (_) { return send(res, 400, 'Bad request', 'text/plain; charset=utf-8', {}, req.method === 'HEAD'); }
    const headOnly = req.method === 'HEAD';
    if (req.method !== 'GET' && !headOnly) {
      res.setHeader('Allow', 'GET, HEAD');
      return send(res, 405, 'Method not allowed', 'text/plain; charset=utf-8');
    }
    return serve(res, pathname, headOnly);
  });
}

if (require.main === module) {
  createServer().listen(PORT, () => {
    console.log(`SA Calculator server listening on http://localhost:${PORT}`);
  });
}

module.exports = { createServer };
