'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '..', 'assets/js/app.js'), 'utf8');
function extract(name) {
  const start = source.indexOf(`function ${name}(`);
  assert.notEqual(start, -1, `${name} not found`);
  const open = source.indexOf('{', start); let depth = 0;
  for (let i = open; i < source.length; i++) {
    if (source[i] === '{') depth++;
    else if (source[i] === '}' && --depth === 0) return source.slice(start, i + 1);
  }
  throw new Error(`Could not extract ${name}`);
}
function runtime() {
  const context = { STATE: { thousandsSep: 'none' }, Math, Number, String, Set, Error };
  vm.runInNewContext([
    extract('toSuperscriptExponent'),
    extract('formatScientificEntryDisplay'),
    extract('isScientificEntryExpression'),
    extract('formatResultNumber'),
    extract('formatCalculatorResultNumber'),
    extract('calculatorIntegerDigitCount'),
    extract('calculatorNeedsScientificNotation'),
    extract('formatCalculatorExpressionResult'),
    'globalThis.isScientificEntryExpression=isScientificEntryExpression;',
    'globalThis.formatScientificEntryDisplay=formatScientificEntryDisplay;',
    'globalThis.formatCalculatorExpressionResult=formatCalculatorExpressionResult;'
  ].join('\n'), context);
  return context;
}
test('bare e is never treated as Euler constant; only complete exponent entries are scientific values', () => {
  const r = runtime();
  assert.equal(r.isScientificEntryExpression('e'), false);
  assert.equal(r.isScientificEntryExpression('e^2'), false);
  assert.equal(r.isScientificEntryExpression('2e'), false);
  assert.equal(r.isScientificEntryExpression('e20'), true);
  assert.equal(r.isScientificEntryExpression('e+20'), true);
  assert.equal(r.isScientificEntryExpression('e-20'), true);
  assert.equal(r.isScientificEntryExpression('2e20'), true);
});
test('scientific-entry formatting is identical for live preview and the equals result path', () => {
  const r = runtime();
  const expected = '1×10²⁰';
  assert.equal(r.formatScientificEntryDisplay(1e20), expected);
  assert.equal(r.formatScientificEntryDisplay(1.234567891234e20), '1.234568×10²⁰');
  assert.equal(r.formatScientificEntryDisplay(9.9999999e12), '1×10¹³');
  assert.equal(r.formatCalculatorExpressionResult('e20', 1e20), expected);
  assert.equal(r.formatCalculatorExpressionResult('e+20', 1e20), expected);
  assert.equal(r.formatCalculatorExpressionResult('1e20', 1e20), expected);
  assert.equal(r.formatCalculatorExpressionResult('e2', 1e2), '100');
  assert.equal(r.formatCalculatorExpressionResult('e-2', 1e-2), '0.01');
  assert.equal(r.formatCalculatorExpressionResult('2e20', 2e20), '2×10²⁰');
});
test('scientific-entry display preserves signed and small exponent magnitudes', () => {
  const r = runtime();
  assert.equal(r.formatCalculatorExpressionResult('e-20', 1e-20), '1×10⁻²⁰');
  assert.equal(r.formatCalculatorExpressionResult('2e-20', 2e-20), '2×10⁻²⁰');
  assert.equal(r.formatCalculatorExpressionResult('e+3', 1e3), '1000');
});

test('all calculator scientific result paths use one-to-six fractional mantissa digits', () => {
  const r = runtime();
  assert.equal(r.formatScientificEntryDisplay(1.234567891234e20), '1.234568×10²⁰');
  assert.equal(r.formatCalculatorExpressionResult('e20', 1.234567891234e20), '1.234568×10²⁰');
  assert.equal(r.formatCalculatorExpressionResult('1×10²⁰×2', 2.469135782468e20), '2.469136×10²⁰');
  assert.equal(r.formatCalculatorExpressionResult('1e-20', 1.234567891234e-20), '1.234568×10⁻²⁰');
});

test('exponent-entry values obey the exact e11/e12 scientific threshold in preview and equals formatting', () => {
  const r = runtime();
  assert.equal(r.formatCalculatorExpressionResult('e11', 1e11), '100000000000');
  assert.equal(r.formatCalculatorExpressionResult('e+11', 1e11), '100000000000');
  assert.equal(r.formatCalculatorExpressionResult('e12', 1e12), '1×10¹²');
  assert.equal(r.formatCalculatorExpressionResult('e+12', 1e12), '1×10¹²');
  assert.equal(r.formatCalculatorExpressionResult('2e11', 2e11), '200000000000');
  assert.equal(r.formatCalculatorExpressionResult('2e12', 2e12), '2×10¹²');
});
